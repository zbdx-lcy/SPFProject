import Vue from "vue";
import VueRouter from "vue-router";
import Report from "../views/Report.vue";
import Main from "../views/Main.vue";
import Data from "@/views/Data.vue";
import Formulation from "@/views/Formulation.vue";
import Form from "../views/Form.vue";
import Home from "../views/Home.vue";
import form1 from "@/views/form1.vue";
import form2 from "@/views/form2.vue";
import form3 from "@/views/form3.vue";
import form4 from "@/views/form4.vue";
import Forecast from "@/views/Forecast.vue";
// import Login from "@/views/Login.vue";

//获取原型对象上的push函数
const originalPush = VueRouter.prototype.push;
//修改原型对象中的push方法
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch((err) => err);
};
Vue.use(VueRouter);

const routes = [
  // {
  //   path: "/",
  //   component: Login,
  // },
  {
    path: "/",
    component: Main,
    redirect: "/formulation",
    children: [
      { path: "formulation", component: Formulation },
      { path: "rhdata", component: Data },
      { path: "form", component: Form },
      { path: "report", component: Report },
      { path: "form1", component: form1 },
      { path: "form2", component: form2 },
      { path: "form3", component: form3 },
      { path: "form4", component: form4 },
      { path: "forecast", component: Forecast },
    ],
  },
];

const router = new VueRouter({
  routes,
});

export default router;
