<template>
    <div>
        <el-menu default-active="1-4-1" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose"
            :collapse="isCollapse" >
            
            <el-menu-item @click="clickMenu(item)" :index="item.name" v-for="item in menuData" :key="item.name">
                <template slot="title">
                    <i :class="item.icon"></i>
                    <span>{{ item.lable }}</span>
                </template>
            </el-menu-item>

            <el-submenu index="1">
                <template slot="title">
                    <i :class="elicon"></i>
                    <span>图表展示</span>
                </template>
                <el-menu-item-group  v-for="item in haschildren" :key="item.lable">
                    <el-menu-item :index="item.path" @click="clickMenu(item)">
                        <template slot="title">
                            <i :class="item.icon"></i>
                            <span>{{ item.lable }}</span>
                        </template>
                    </el-menu-item>
                </el-menu-item-group>
            </el-submenu>
        </el-menu>
    </div>
</template>


<style lang="less" scoped>
.el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
    position: sticky;
    top: 0;
    left: 0;
    float: left;
    overflow-y: auto;
    display: block;
    box-sizing: border-box;
    
    //margin-top: 5px;
}

.el-menu {
    height: 91vh;
    background-color:"#FFFFFF" ;
    color:"#6E7078";
    
   
    h3 {
        color: black;
        text-align: center;
        line-height: 65px;
        font-size: 19px;
        font-family: Open Sans, sans-serif;
    }
    i {
        color: #5A6FC0;
    }
}

.el-menu-item.is-active {
    //没作用
    background-color: #5A6FC0;
    color: #ffffff;

    i {
        color: #ffffff;
    }
}
</style>

<script>
export default {
    data() {
        return {
            elicon: "el-icon-pie-chart",
            menuData: [
                {
                    path: "/formulation",
                    name: "formulation",
                    lable: "配方展示",
                    url: "",
                    icon: "el-icon-document"
                },
                {
                    path: "/rhdata",
                    name: "rhdata",
                    lable: "流变数据",
                    url: "",
                    icon: "el-icon-data-analysis"
                },
                {
                    path: "/report",
                    name: "report",
                    lable: "报告展示",
                    url: "",
                    icon: "el-icon-reading"
                },
                {
                    path: "/forecast",
                    name: "forecast",
                    lable: "数据预测",
                    url: "",
                    icon: "el-icon-data-line"
                }
            ],
            haschildren: [
                {
                    path: "/form1",
                    name: "form1",
                    lable: "时间-损耗因子图",
                    url: ""
                },
                {
                    path: "/form2",
                    name: "form2",
                    lable: "时间-模量图",
                    url: ""
                },
                {
                    path: "/form3",
                    name: "form3",
                    lable: "固化终点-模量图",
                    url: ""
                },
                {
                    path: "/form4",
                    name: "form4",
                    lable: "时间-复数黏度图",
                    url: ""
                }
            ]
        };
    },
    methods: {
        handleOpen(key, keyPath) {
            console.log(key, keyPath);
        },
        handleClose(key, keyPath) {
            console.log(key, keyPath);
        },
        clickMenu(item) {
            //路径不同能跳
            if (this.$router.path !== item.path || (this.$router.path === '/formulation' && (item.path === '/'))) {
                this.$router.push(item.path);
            }
        }
    },
    computed: {
        isCollapse() {
            return this.$store.state.tab.isCollapse
        }
    }
}
</script>