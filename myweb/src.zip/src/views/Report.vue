<template>
  <div>
    <div class="top">
      <div class="file-upload-container">

      </div>
      <div class="search-container">
        <el-input v-model="formulationId" placeholder="请输入配方ID"></el-input>
        <el-input v-model="temperatureId" placeholder="请输入温度"></el-input>
        <el-button type="primary" @click="fetchData">查询</el-button>
      </div>
    </div>
    <div>
      <canvas ref="pdfCanvas"></canvas>
    </div>
  </div>
</template>

<script>
import pdfjs from 'pdfjs-dist/build/pdf';
import axios from 'axios';
export default {
  data() {
    return {
      formulationId: '',
      temperatureId: '',
      pdfUrl: '', // 从后端获取的PDF文件地址
      pdfjsLib: null,
      pdfDoc: null,
      pageNum: 1,
    };
  },
  mounted() {
    this.pdfjsLib = pdfjs;
    this.getPdfUrl(); // 获取PDF地址
  },
  methods: {
    methods: {
      getPdfUrl() {
        axios.get('/api/getPdfUrl', {
          params: {
            formulationId: this.formulationId,
            temperatureId: this.temperatureId
          }
        })
          .then(response => {
            this.pdfUrl = response.data.url;
            this.renderPdf();
          })
          .catch(error => {
            console.error('获取PDF地址失败', error);
          });
      },
    },
    renderPdf() {
      const loadingTask = this.pdfjsLib.getDocument(this.pdfUrl);
      loadingTask.promise.then(pdf => {
        this.pdfDoc = pdf;

        this.renderPage(this.pageNum);
      }).catch(error => {
        console.error('加载错误', error);
      });
    },
    renderPage(num) {
      this.pdfDoc.getPage(num).then(page => {
        const canvas = this.$refs.pdfCanvas;
        const context = canvas.getContext('2d');

        const viewport = page.getViewport({ scale: 1.5 });
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
          canvasContext: context,
          viewport: viewport
        };

        page.render(renderContext);
      }).catch(error => {
        console.error('Error rendering page:', error);
      });
    }
  }
};
</script>

<style lang="less" scoped>
.top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  .file-upload-container {
    margin-right: 20px;
  }

  .search-container {
    display: flex;
    align-items: center;
  }

  .el-input {
    width: 150px;
    margin-right: 20px;
  }
}
</style>
