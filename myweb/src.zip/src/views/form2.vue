<template>
  <div class="container-lg">

    <div class="top">
      <el-input v-model="fid" placeholder="请输入配方ID"></el-input>
      <el-button type="primary" @click="fetchData">查询</el-button>
    </div>

    <h2 class="text-center mt-4 mb-4">时间-模量图展示</h2>
    <h3 class="text-center">配方 {{ formulation.formulation_id }} - {{ formulation.formulationName }}</h3>
    <br>
    <div class="row" style="max-height: 80vh; overflow: auto;">
      <div v-for="temperature in temperatures" :key="temperature.temp_id" class="col-16 col-md-16 col-lg-12 mb-12">
        <h4 class="text-center">{{ temperature.temp_value }} °C</h4>
        <div class="d-flex justify-content-center align-items-center chart-container" style="height: 50vh;">
          <div class="chart-container" :id="'chart_' + formulation.formulation_id + '_' + temperature.temp_id"
            style="width: 1000px; height: 400px;"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import axios from 'axios';

export default {
  name: 'TimeModulusChart',
  data() {
    return {
      // formulationId: null,
      // formulationName: '',
      formulation: {},
      temperatures: [],
      relatedData: [],
      fid: 1,
      data: [],
      time_min: [],
      loss_mod: [],
      energy_storage_mod: [],
      chartData: [],
    }
  },
  async mounted() {
    await this.fetchData();

  },
  methods: {
    async fetchData() {
      try {
        // 假设有一个API端点 "/api/formulationData" 返回所有所需数据
        const response = await axios.get(`/formulation/time_mod_fig/${this.fid}`);
        this.formulation = response.data.formulation;
        this.temperatures = response.data.temperatures;
        this.relatedData = response.data.relatedData;
        this.temperatures.forEach((temperature) => {
          const sampleInterval = Math.ceil(this.relatedData.length / 5000);
          this.data = this.relatedData.filter((item, index) => {
            return index % sampleInterval === 0 && item.temperature_id_id === temperature.temp_id;
          });
          this.timeMin = this.data.map(item => item.time_min);
          this.loss_mod = this.data.map(item => [item.time_min, Math.log10(item.loss_mod), item.loss_mod]);
          this.energy_storage_mod = this.data.map(item => [item.time_min, Math.log10(item.energy_storage_mod), item.energy_storage_mod]);
          this.initChart(temperature);
        });
      } catch (error) {
        console.error('获取数据失败:', error);
      }
    },
    initChart(temperature) {
      const chartID = document.getElementById('chart_' + this.formulation.formulation_id + '_' + temperature.temp_id);
      const chart = echarts.init(chartID);

      const option = {
        title: {
          text: '时间-模量图',
          left: 'center'
        },
        tooltip: {
          trigger: 'axis',
          formatter: (params) => {
            var time = params[0].value[0];
            var lossModValue = params[0].value[2].toFixed(2);
            var energyStorageModValue;
            try {
              params.forEach((item) => {
                if (item.seriesName.indexOf('储能模量') !== -1) {
                  energyStorageModValue = item.value[2].toFixed(2);
                  throw Error();
                }
              });
            } catch (e) {
            }
            return 'Time: ' + time + '<br>' +
              temperature.temp_value + '°C' + '损耗模量: ' + lossModValue + '<br>' +
              temperature.temp_value + '°C' + '储能模量: ' + energyStorageModValue;
          }
        },
        xAxis: {
          type: 'value',
          name: '时间(min)',
          data: this.time_min,
          nameTextStyle: { // 坐标轴名称样式
            fontFamily: 'Times New Roman, serif',
            fontSize: 14,
            fontWeight: 'bold',
          },
          axisLabel: { // 坐标轴刻度标签的样式
            color: '#999',
            fontFamily: 'Georgia, serif',
            fontSize: 12,
          }
        },
        yAxis: {
          type: 'value',
          name: '模量(log10)',
          nameTextStyle: { // 坐标轴名称样式
            fontFamily: 'Times New Roman, serif',
            fontSize: 14,
            fontWeight: 'bold',
          },
          axisLabel: {
            formatter: function (value, index) {
              return value.toFixed(0);
            }
          },
        },
        series: [{
          data: this.energy_storage_mod,
          type: 'line',
          name: temperature.temp_value + '°C' + '储能模量',
          smooth: true,
          tooltip: {
            show: true // 数据点显示tooltip
          }
        },
        {
          data: this.loss_mod,
          type: 'line',
          name: temperature.temp_value + '°C' + '损耗模量',
          smooth: true,
          tooltip: {
            show: true // 数据点显示tooltip
          }
        }]
      };
      chart.setOption(option);

      // this.chartData.push({
      //   formulationId: this.formulation.formulation_id,
      //   temperatureId: temperature.temp_id,
      //   data: this.data,
      //   option: option,

      // });
      const fileName = `TimeModulusChart_${this.formulation.formulation_id}_${temperature.temp_id}.png`;
      this.saveChartImage(temperature,fileName);

    },

    saveChartImage(temperature,fileName) {
      const chartID = 'chart_' + this.formulation.formulation_id + '_' + temperature.temp_id;
      const chart = echarts.getInstanceByDom(document.getElementById(chartID));
      const base64ImageData = chart.getDataURL({ pixelRatio: 2 });

      const blob = this.dataURItoBlob(base64ImageData);
      const formData = new FormData();
      formData.append('chartImage', blob, fileName);


      axios.post('/upload/chart2/image', formData)
        .then(response => {
          console.log('Image uploaded successfully:', response.data);
        })
        .catch(error => {
          console.error('Failed to upload image:', error);
        });
    },

    dataURItoBlob(dataURI) {
      const byteString = atob(dataURI.split(',')[1]);
      const ab = new ArrayBuffer(byteString.length);
      const ia = new Uint8Array(ab);

      for (let i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
      }

      return new Blob([ab], { type: 'image/png' });
    },
  },

}
</script>

<style lang="less" scoped>
.container-lg {
  .top {
    text-align: end;

    .el-input {
      width: 150px;
      margin-right: 20px;
    }
  }

  h2 {
    font-weight: bold;
    color: #333;
    font-style: normal;
    font-family: 'Arial, sans-serif';
    font-size: 25px;
    text-align: center;
  }

  h3 {
    text-align: center;
    color: #333;
    font-family: 'Arial, sans-serif';
  }

  h4 {
    text-align: center;
    color: #333;
    font-family: 'Arial, sans-serif';
  }

  .chart-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 200px;
  }
}
</style>