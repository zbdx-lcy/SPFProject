<template>
  <div class="data-form">
    <div class="top">
      <div class="file-upload-container">
        <el-upload class="file-upload" action="/rhdata/rhdata_add/" :on-success="handleUploadSuccess"
                   :before-upload="beforeUpload">
          <el-button type="primary">点击上传配方对应的流变性质数据</el-button>
          <!--      <div slot="tip" class="el-upload_tip">只能上传excel文件</div>-->
        </el-upload>
      </div>
      <div class="search-container">
        <el-input v-model="formulationId" placeholder="请输入配方ID"></el-input>
        <el-input v-model="temperatureId" placeholder="请输入温度"></el-input>
        <el-button type="primary" @click="fetchData">查询</el-button>
      </div>
    </div>

    <el-table :data="pagedData" style="width: 100%; margin-top: 20px;" stripe>
      <el-table-column prop="rh_id" label="数据编号" align="center"></el-table-column>
      <!-- <el-table-column prop="formulation_id_id" label="Formulation ID"></el-table-column>
      <el-table-column prop="temperature_id_id" label="Temperature ID"></el-table-column>
      <el-table-column prop="temp_mark" label="温度 °C"></el-table-column> -->
      <el-table-column prop="time_min" label="时间 (min)" align="center"></el-table-column>
      <!-- <el-table-column prop="time_s" label="Time (s)"></el-table-column> -->
      <el-table-column prop="temp" label="温度 °C" align="center"></el-table-column>
      <el-table-column prop="energy_storage_mod" label="储能模量" align="center"></el-table-column>
      <el-table-column prop="loss_mod" label="损耗模量" align="center"></el-table-column>
      <el-table-column prop="loss_factor" label="损耗因子" align="center"></el-table-column>
      <el-table-column prop="complex_viscosity" label="复数黏度" align="center"></el-table-column>
      <el-table-column prop="clearances" label="间隙" align="center"></el-table-column>
      <el-table-column prop="normal_force" label="法向力" align="center"></el-table-column>
      <el-table-column prop="torsion" label="扭矩" align="center"></el-table-column>
      <el-table-column prop="state_mark" label="状态" align="center"></el-table-column>
    </el-table>

    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
                   :page-size="pageSize" layout="total ,prev, pager, next, jumper" :total="totalItems">
    </el-pagination>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      formulationId: '',
      temperatureId: '',
      currentPage: 1,
      pageSize: 10,
      totalItems: 0,
      allData: [], //后端传入的所有数据
      pagedData: [], //某一页的数据
    };
  },
  methods: {
    handleUploadSuccess(response, file, fileList) {
      this.$message.success('文件上传成功');
      this.fetchData();
    },
    beforeUpload(file) {
      
      const isExcel = file.type === 'application/vnd.ms-excel' || 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
      if (!isExcel) {
        this.$message.error('只能上传Excel文件');
        console.log(file.type);
      }
      return isExcel;
    },
    fetchData() {
      //  带参请求
      axios.get('/rhdata/rhdata_list/', {  //接口改一下
        params: {
          formulation_id_id: this.formulationId,
          temperature_id_id: this.temperatureId,
        }
      }).then(response => {
        this.allData = response.data;
        this.totalItems = this.allData.length;
        this.updatePageData();
      }).catch(error => {
        console.error('没有找到该数据:', error);
      });
    },
    updatePageData() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = start + this.pageSize;
      this.pagedData = this.allData.slice(start, end);  //这里会根据pagesize截取对应个数的items
    },
    handleCurrentChange(newPage) {
      this.currentPage = newPage;
      this.updatePageData();
    }
  }
};
</script>

<style lang="less" scoped>
.data-form {
  height: 90%;
  display: flex;
  flex-direction: column;
}

.top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;

  .file-upload-container {
    margin-right: 20px;
  }

  .search-container {
    display: flex;
    align-items: center;
  }
  .el-input {
    width: 150px;
    margin-right: 20px;
  }
}
</style>
