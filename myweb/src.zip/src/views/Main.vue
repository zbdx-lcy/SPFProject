<!-- eslint-disable vue/multi-word-component-names -->
<template>
    <div>
        <router-view></router-view>
    </div>
</template>
<script>

</script>