<template>
  <div class="container-lg">
    <div class="top">
      <el-input v-model="fid" placeholder="请输入配方ID"></el-input>
      <el-button type="primary" @click="fetchData">查询</el-button>
    </div>

    <h2 class="text-center mt-4 mb-4">时间-复数黏度图展示</h2>
    <h3 class="text-center">配方 {{ formulation.formulation_id }}</h3>
    <br>
    <div class="row" style="max-height: 80vh; overflow: auto;">
      <div v-for="temperature in temperatures" :key="temperature.temp_id" class="col-16 col-md-16 col-lg-12 mb-12">
        <h4 class="text-center">{{ temperature.temp_value }} °C</h4>
        <div class="d-flex justify-content-center align-items-center chart-container" style="height: 50vh;">
          <div :id="'chart_' + formulation.formulation_id + '_' + temperature.temp_id" class="chart-container"
               style="width: 1000px; height: 400px;"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from 'echarts';
import axios from 'axios';

export default {
  name: 'TimeComplexViscosityChart',
  data() {
    return {
      formulation: {},
      temperatures: [],
      relatedData: [],
      fid: 1,
      data: [],
      timeMin: [],
      complexViscosity: []
    };
  },
  async mounted() {
    await this.fetchData();
  },
  methods: {
    async fetchData() {
      try {
        // 假设这是你的API端点
        const Response = await axios.get(`/formulation/time_viscosity_fig/${this.fid}`);
        this.formulation = Response.data.formulation;
        this.temperatures = Response.data.temperatures;
        this.relatedData = Response.data.relatedData;
        this.temperatures.forEach((temperature) => {
          const sampleInterval = Math.ceil(this.relatedData.length / 3000);
          this.data = this.relatedData.filter((item, index) => {
            return index % sampleInterval === 0 && item.temperature_id_id === temperature.temp_id;
          });
          this.timeMin = this.data.map(item => item.time_min);
          this.complexViscosity = this.data.map(item => [item.time_min, item.complex_viscosity]);
          this.initCharts(temperature);
        });
      } catch (error) {
        console.error('Failed to fetch data:', error);
      }
    },
    initCharts(temperature) {
      const chart = echarts.init(document.getElementById('chart_' + this.formulation.formulation_id + '_' + temperature.temp_id));

      const option = {
        title: {
          text: '时间-复数黏度图',
          left: 'center',
          top: 20,
          textStyle: {
            color: 'black'
          }
        },

        tooltip: {
          trigger: 'axis',
          formatter: (params) => {
            const time = params[0].value[0];
            const complex_viscosity = params[0].value[1].toFixed(2);
            return 'Time: ' + time + '<br>' +
                temperature.temp_value + '°C' + '复数黏度: ' + complex_viscosity
          }
        },
        xAxis: {
          type: 'value',
          data: this.timeMin
        },
        yAxis: {
          type: 'value',
          name: '复数黏度',
          axisLabel: {
            formatter: (value, index) => {
              return value.toFixed(0); // 将值保留两位小数
            }
          },
        },
        series: [
          {
            name: temperature.temp_value + '°C' + '复数黏度',
            type: 'line',
            data: this.complexViscosity,
            lineStyle: {
              color: 'blue'
            },
            emphasis: {
              focus: 'series'
            },
            symbol: 'circle', // 设置数据点的形状为圆形
            symbolSize: 8, // 设置数据点的大小
            tooltip: {
              show: true // 数据点显示tooltip
            }
          },
        ]
      };

      chart.setOption(option);

      // 导出图表
      const base64Data = chart.getDataURL({
        pixelRatio: 2,
        backgroundColor: '#fff'
      });

      const blob = this.base64ToBlob(base64Data);
      const fileName = `TimeComplexViscosityChart_${this.formulation.formulation_id}_${temperature.temp_id}.png`;
      const file = new File([blob], fileName, { type: 'image/png' });

      // 使用fetch将文件上传到服务器
      const formData = new FormData();
      formData.append('file', file);

      fetch('/upload/chart4/image', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        console.log('File uploaded:', data);
      })
      .catch(error => {
        console.error('Failed to upload file:', error);
      });
    },
    base64ToBlob(base64Data) {
      const parts = base64Data.split(';base64,');
      const contentType = parts[0].split(':')[1];
      const raw = window.atob(parts[1]);
      const rawLength = raw.length;
      const uInt8Array = new Uint8Array(rawLength);

      for (let i = 0; i < rawLength; ++i) {
        uInt8Array[i] = raw.charCodeAt(i);
      }

      return new Blob([uInt8Array], { type: contentType });
    }
  }
}
</script>

<style lang="less" scoped>
.container-lg {
  .top {
    text-align: end;

    .el-input {
      width: 150px;
      margin-right: 20px;
    }
  }

  h2 {
    font-weight: bold;
    color: #333;
    font-style: normal;
    font-family: 'Arial, sans-serif';
    font-size: 25px;
    text-align: center;
  }

  h3 {
    text-align: center;
    color: #333;
    font-family: 'Arial, sans-serif';
  }

  h4 {
    text-align: center;
    color: #333;
    font-family: 'Arial, sans-serif';
  }

  .chart-container {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    height: 200px;
  }
}
</style>
