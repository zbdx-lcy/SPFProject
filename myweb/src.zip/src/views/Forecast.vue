<template>
  <div class="data-form">
    <div class="top">
      <div class="search-container">
        <el-input v-model="formulationId" placeholder="请输入配方ID"></el-input>
        <el-input v-model="temperatureId" placeholder="请输入温度"></el-input>
        <div class="button-group">
          <el-button @click="showTrainForm = true;" type="primary">训练</el-button>
          <el-button @click="handlePredict" type="success">预测</el-button>
        </div>
      </div>
      <el-dialog :visible="showDialog" title="训练提示" @close="showDialog = false" width="30%"
        custom-class="training-dialog">
        <p>训练已完成</p>
      </el-dialog>

      <el-dialog :visible="showTrainForm" title="训练参数配置" @close="showTrainForm = false" class="btnright">
        <el-form :model="inputParams" label-width="120px">
          <el-form-item label="学习率">
            <el-input v-model="inputParams.learningRate" placeholder="请输入学习率"></el-input>
          </el-form-item>
          <el-form-item label="批大小">
            <el-input v-model="inputParams.batchSize" placeholder="请输入批大小"></el-input>
          </el-form-item>
          <el-form-item label="训练轮数">
            <el-input v-model="inputParams.epochs" placeholder="请输入训练轮数"></el-input>
          </el-form-item>
          <div class="button-container">
            <el-button type="primary" @click="trainModel(inputParams)">确定</el-button>
            <el-button @click="showTrainForm = false">取消</el-button>
          </div>
        </el-form>
      </el-dialog>

      <el-dialog :visible="trainingInProgress || predictionInProgress" center :show-close="false">
        <div v-if="trainingInProgress">训练中</div>
        <div v-if="predictionInProgress">预测中</div>
        <el-progress :percentage="progress" :color="trainingInProgress ? '#0c64e8' : '#13ce66'"></el-progress>
      </el-dialog>
    </div>

    <el-table :data="pagedData" style="width: 100%; margin-top: 20px;" stripe>
      <el-table-column prop="rh_id" label="数据编号" align="center"></el-table-column>
      <el-table-column prop="time_min" label="时间 (min)" align="center"></el-table-column>
      <el-table-column prop="temp" label="温度 °C" align="center"></el-table-column>
      <el-table-column prop="energy_storage_mod" label="储能模量" align="center"></el-table-column>
      <el-table-column prop="loss_mod" label="损耗模量" align="center"></el-table-column>
      <el-table-column prop="loss_factor" label="损耗因子" align="center"></el-table-column>
      <el-table-column prop="complex_viscosity" label="复数黏度" align="center"></el-table-column>
      <el-table-column prop="clearances" label="间隙" align="center"></el-table-column>
      <el-table-column prop="normal_force" label="法向力" align="center"></el-table-column>
      <el-table-column prop="torsion" label="扭矩" align="center"></el-table-column>
      <el-table-column prop="state_mark" label="状态" align="center"></el-table-column>
    </el-table>

    <el-pagination @current-change="handleCurrentChange" :current-page="currentPage" :page-size="pageSize"
      layout="total ,prev, pager, next, jumper" :total="totalItems">
    </el-pagination>
  </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      formulationId: '',
      temperatureId: '',
      currentPage: 1,
      pageSize: 10,
      totalItems: 0,
      allData: [], // 后端传入的所有数据
      pagedData: [], // 某一页的数据
      inputParams: {
        learningRate: '',
        batchSize: '',
        epochs: ''
      },
      trainingInProgress: false,
      predictionInProgress: false,
      progress: 0,
      showDialog: false,
      showTrainForm: false
    };
  },
  methods: {
    fetchData() {
      //  带参请求
      axios.get('/fcdata/fcdata_list/', {
        params: {
          formulation_id_id: this.formulationId,
          temperature_id_id: this.temperatureId,
        }
      }).then(response => {
        this.allData = response.data;
        this.totalItems = this.allData.length;
        this.updatePageData();
      }).catch(error => {
        console.error('没有找到该数据:', error);
      });
    },
    updatePageData() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = start + this.pageSize;
      this.pagedData = this.allData.slice(start, end);  //这里会根据pagesize截取对应个数的items
    },
    handleCurrentChange(newPage) {
      this.currentPage = newPage;
      this.updatePageData();
    },
    trainModel(params) {   //传入输入的训练数据
      console.log(params)
      this.trainingInProgress = true;
      // 将训练参数、配方id、温度一起传给后端
      axios.post('/train_model/', {
        formulationId: this.formulationId,
        temperatureId: this.temperatureId,
        learningRate: params.learningRate,
        batchSize: params.batchSize,
        epochs: params.epochs
      }).then(response => {
        // 处理训练结果
        console.log('训练完成:', response.data);
        this.trainingInProgress = false;
        this.progress = 0; // 重置进度条
        this.showTrainForm = false; // 关闭参数配置表单
        this.showDialog = true; // 弹出训练完成提示框
      }).catch(error => {
        console.error('训练失败:', error);
        this.trainingInProgress = false;
      });
    },
    handlePredict() {
      this.predictionInProgress = true;
      // 只将id和温度传给后端
      axios.post('/make_prediction/', {
        formulationId: this.formulationId,
        temperatureId: this.temperatureId
      }).then(response => {
        // 处理预测结果
        console.log('预测完成:', response.data);
        this.predictionInProgress = false;
        this.progress = 0; // 重置进度条
      }).catch(error => {
        console.error('预测失败:', error);
        this.predictionInProgress = false;
      });
    }
  }
};
</script>

<style lang="less" scoped>
.data-form {
  height: 90%; /* 使用视窗高度作为高度 */
  display: flex;
  flex-direction: column;

  .top {
    display: flex;
    justify-content: end;
    align-items: center;
    margin-bottom: 20px;

    .search-container {
      display: flex;
      align-items: center;

      .el-input {
        width: 150px;
        margin-right: 20px;
      }
    }

    .button-group {
      display: flex;
      align-items: center;
      
      .el-button {
        justify-content: end;
        margin-right: 10px;
      }
    }
  }
}
</style>